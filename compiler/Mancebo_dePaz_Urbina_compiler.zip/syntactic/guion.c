main {
int x;
x = 8;
 printf x;
}